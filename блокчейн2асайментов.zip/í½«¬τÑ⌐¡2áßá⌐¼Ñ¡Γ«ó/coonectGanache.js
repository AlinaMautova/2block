const Web3 = require('web3');

// Replace 'YOUR_INFURA_PROJECT_ID' with your Infura API key
const ETHEREUM_NETWORK = "sepolia";
const infuraUrl = 'b2b16a170dc44a90a83e545cc22489ad';
const infuraProvider = `https://${ETHEREUM_NETWORK}.infura.io/v3/${infuraUrl}`;
const contractAddress = '0xCa28e6D5aE6df09F6C37Ed7D7B2b681043d5a232';
const senderAddress = '0xCa28e6D5aE6df09F6C37Ed7D7B2b681043d5a232';
const privateKey = '030c70a61140a440351ec5acbf5e0a9a81a938687a80ebf933ebc66dee1195fd'; // Add your private key here

const web3 = new Web3(infuraProvider);

// Replace with the ABI of your contract
const contractAbi = [
  // ... ABI content ...
];

const myContract = new web3.eth.Contract(contractAbi, contractAddress);

const txParams = {
  from: senderAddress,
  to: contractAddress,
  data: myContract.methods.getTransactionSender().encodeAlIna(),
  gas: 200000, // Adjust the gas limit accordingly
  gasPrice: '100000000000'
};

const main = async () => {
  try {
    const result = await myContract.methods.getTransactionReceiverAddress().call();

    // Log the result
    console.log("Transaction Sender:", result);

    // Now you can proceed with the transaction
    const signedTx = await web3.eth.accounts.signTransaction(txParams, privateKey);
    const receipt = await web3.eth.sendSignedTransaction(signedTx.rawTransaction);
    console.log(receipt);
    console.log("Transaction successful!");
  } catch (error) {
    console.error("Transaction failed:", error);
  }
};

main();
